class CardList {
  String imageUrl;
  String address;
  String writer;

  CardList(
      {required this.imageUrl, required this.address, required this.writer});
}

List<CardList> cardList = [
  CardList(
      imageUrl: "assets/images/img1.png",
      address: "Kab. Tanggerang, Banten",
      writer: "Carwash park paramount gading serpong"),
  CardList(
      imageUrl: "assets/images/img2.png",
      address: "Kab. Tanggerang, Banten",
      writer: "Carwash park paramount gading serpong"),
  CardList(
      imageUrl: "assets/images/img3.png",
      address: "Kab. Tanggerang, Banten",
      writer: "Carwash park paramount gading serpong"),
  CardList(
      imageUrl: "assets/images/img4.png",
      address: "Kab. Tanggerang, Banten",
      writer: "Carwash park paramount gading serpong"),
  CardList(
      imageUrl: "assets/images/img5.png",
      address: "Kab. Tanggerang, Banten",
      writer: "Carwash park paramount gading serpong"),
  CardList(
      imageUrl: "assets/images/img5.png",
      address: "Kab. Tanggerang, Banten",
      writer: "Carwash park paramount gading serpong"),
];
